Joseph Edradan
11/2/2021
920783419

The main stuff that was implemented was primarily based on the idea of value iteration, the bellman equation,
and the temporal difference equation. Basically, you run a game instance and the AI gets a score and you repeat this
process where the AI retains the knowledge that it knows from the previous games to influence its gameplay along
with some randomness and some tuning values to influence its thought process. The AI keeps doing this until you're
satisfied with its gameplay or you hit some limit where the AI can't play the game anymore.
The combined knowledge of the AI playing the game is called a policy and the AI uses that policy
to play the game better than it did before.

Hours spent doing this project: 20+