Joseph Edradan
10/6/2021
920783419

The main ideas implemented in this assigment are Minimax, Expectimax, UCS (which is currently set to BFS). For Q1 and
Q5, they use the same evaluation function. The Evaluation for Q1 and Q5 are to get the influence of Active ghosts,
Scared ghosts, and food to influence the score. Also I manually fined tuned exponents for the evaluation function in
Q1 and Q5 to get big points. For Q2 and Q3 they use the same algorithm but Q3 has the alpha_beta_pruning flag set to
True. Q4 is just copy and paste of the algorithm of Q2 and Q3 but change the minimizer to summation of expectations.

Hours spent doing this project: ~20